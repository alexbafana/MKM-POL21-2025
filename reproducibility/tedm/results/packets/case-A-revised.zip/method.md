# Revised TEDM study guide


1. Frame stakeholders, goals, desired behaviors, functions, and justified authority boundaries.
2. Apply the same original incentive, governance, and token-policy steps. Record choices, rationale, alternatives, assumptions, and evidence.
3. Review material rights and distinguish ownership, effective voting power, latent capacity, and exercised control. Trace interactions across pillars and lifecycle stages.
4. Record treatment, tradeoffs, residual risk, prospective monitoring, ownership, and escalation. Revise if residual exposure is unacceptable; record who accepts it.
5. Link accepted goals, choices, pathways, monitoring, and engineering requirements with stable identifiers. Preserve unsupported details in external records and mark unknowns explicitly.

